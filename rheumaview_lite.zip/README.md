# RheumaView Lite (Streamlit + PyTorch)

This is a minimal working prototype of the RheumaView Lite system.

## 🔧 How to run

```bash
# Step 1: Install dependencies
pip install torch torchvision streamlit pillow

# Step 2: Run the app
streamlit run app_streamlit.py
```

## 📂 Files

- `inference_core.py` — contains the model and prediction logic
- `app_streamlit.py` — the main UI app
- `class_names` — editable list of anatomical labels

## ✅ How to test

1. Run the app locally.
2. Upload an X-ray image (JPG, PNG, WEBP).
3. You will see the predicted anatomical region.

**Note:** Current model is ResNet-18 pretrained on ImageNet, so predictions are simulated with mock labels for demo.
