import streamlit as st
from PIL import Image
from inference_core import predict_region

st.set_page_config(page_title="RheumaView Lite", layout="centered")
st.title("🩻 RheumaView Lite")

uploaded_file = st.file_uploader("Upload an X-ray image", type=["jpg", "png", "webp"])

if uploaded_file:
    image = Image.open(uploaded_file).convert("RGB")
    st.image(image, caption="Uploaded X-ray", use_column_width=True)
    with st.spinner("Analyzing..."):
        pred = predict_region(image)
    st.success(f"🧠 Predicted region: **{pred}**")
