# RheumaView-lite v4.2-fallback-select

This version allows manual selection of anatomical region when prediction is unavailable.

## Features
- Fallback selectbox per file if region = "Unknown"
- Report summary includes override note
- Keeps architecture ready for AI-based prediction

## Run:
```
pip install -r requirements.txt
streamlit run app.py
```
