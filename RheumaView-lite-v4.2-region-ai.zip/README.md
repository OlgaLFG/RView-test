# RheumaView-lite v4.2-region-ai

AI-powered anatomical region classifier using ResNet18.

## Features
- Predicts region per image using deep model
- Top-3 confidences shown
- Manual override (selectbox) if prediction is uncertain
- READY generates a source-aware report

## Usage
Place `region_model.pt` in the same directory.
```
pip install -r requirements.txt
streamlit run app.py
```
