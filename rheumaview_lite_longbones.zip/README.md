# RheumaView Lite (Streamlit + PyTorch)

This is a minimal working prototype of the RheumaView Lite system.

## 🔧 How to run

```bash
# Step 1: Install dependencies
pip install -r requirements.txt

# Step 2: Run the app
streamlit run app_streamlit.py
```
