# RheumaView-lite v3.1

English-language debug interface for radiology AI app. Classifies uploaded X-ray images by region using filename and image dimensions.

## Features
- Combined classifier (filename + image shape)
- Groups files into regions (e.g., SI joints, hands, spine)
- Scalable image preview with caption
- English UI (fully translated)

## Run locally:
```
pip install -r requirements.txt
streamlit run app.py
```

## Use on Streamlit Cloud
Ensure `.python-version` is present and contains `3.10`
