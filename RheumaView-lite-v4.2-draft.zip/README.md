# RheumaView-lite v4.2-draft

This draft includes a placeholder for a visual region classifier (`predict_region(image)`) with manual override.

- Use selectbox to manually set anatomical region if classifier returns low confidence.
- Designed for future integration of trained models.

## Run
```
pip install -r requirements.txt
streamlit run app.py
```
