# RheumaView-lite v4.1-ai

Prototype for AI-generated summaries per anatomical region.

## Features
- Region classification (filename-based)
- AI interpretation with confidence-based phrasing
- Final summary report triggered by READY button

To run:
```
pip install -r requirements.txt
streamlit run app.py
```
