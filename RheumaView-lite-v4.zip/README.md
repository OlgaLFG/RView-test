# RheumaView-lite v4

Basic classification + READY logic + preview adjustment

## Features
- Auto-classifies by region using filename and geometry
- Preview size reduced to 180px
- READY button to generate grouped summary report

## Usage
```
pip install -r requirements.txt
streamlit run app.py
```

Ensure `.python-version` = 3.10 for Streamlit Cloud
